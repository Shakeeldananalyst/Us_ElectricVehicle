Use US_ev;
Desc Electric_vehicle_population_data;

Rename Table Electric_vehicle_population_data to EVD;


-- Which company dominates the Market

 
 -- Q1 Highest Car Selling Companies
 Select *, Dense_Rank() Over(Order by E.No Desc)
 From
 (Select 
 Make, 
 Model, 
 Count(Model) No
 From EVD
 Group by Make,
		  Model) E;
  
  /* Observation, Tesla Sold the maxium cars, Model Y and Model 3 were the best sellers, there is a high volumne differnce that can be seen between 
  Nissan(which aqires the 3 position) and Tesla again holds the position at 4th place.*/
  
  -- Q2 in the continuity to Q1 Which was the year when tesla sell the most.
  

SELECT ModelYear, 
       COUNT(VIN) AS CountOfVIN, 
       DENSE_RANK() OVER (ORDER BY COUNT(VIN) DESC) AS Ranc
FROM EVD
WHERE Make = 'Tesla'
GROUP BY ModelYear;
         
         
/* Tesla's sales gradually increased until 2017, after which the growth pace accelerated significantly, showing fluctuations. The peak 
year was 2023 with sales exceeding 200% of previous years, before dropping sharply.*/

-- Q3 in continuity to Q2, which was the Maxium sold vehicle during the peak years.

   Select Count(distinct Model) from Evd
   Where Make='Tesla';
   -- Tesla has in total 6 models
   
   Select ModelYear,
          Count(distinct Model),
          group_concat(Distinct Model, ' ')
          From Evd
          Where Make='Tesla'
          Group by 1; 
          
      Select Model,
          Count(Model),
          Dense_rank() Over( Order by Count(Model) desc)
          From Evd
          Where ModelYear = '2017' and '2024'  and Make='Tesla'
          Group by 1; 
          
   Select Model,
          Count(Model),
          Dense_rank() Over( Order by Count(Model) desc)
          From Evd
          Where ModelYear between'2017' and '2024' and Make='Tesla'
          Group by 1;

/*  Observation- Roadster was not sold after 2011, 
after 2016 model 3 was introduced which increased the Sales sky high but then Model Y even exceeded the Model S.*/

-- over the years how much increment was there in tesla sales.

With SOY AS
    (  Select Modelyear,
              Count(VIN) As Evs
       from Evd
       where Make='Tesla'
       Group by 1
       Order by 1
       )
       
Select *,
       Round(((EVS- Lag(Evs) Over(order by Modelyear))/ Lag(Evs) Over(order by Modelyear)) *100) AS ChangeinpercentSales
from SOY;
       
 -- 2023 around 105% of increament was seen in the sales of tesla.      
-- xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


-- Q1 shows highest to lowest Evs in a County
Select County, Count(Vin) Count_EVs
From Evd
Group by 1
Order by 2 desc;

-- Q2 Which city has the maximum EV grouped by county.
SELECT 
    *,
    DENSE_RANK() OVER (ORDER BY E.EVs DESC) 
FROM
    (SELECT 
		County, 
        City, 
        
        COUNT(VIN) AS EVs
    FROM 
        Evd
    GROUP BY 
		County, 
        City) E;
        
-- Observation Kings is the maxium EV puchasing County, in which Siattle purchased the majority of these Vehicles.alter

-- in continuity of Q1 and 2, find the company which excels most in Kings and then in siattle.


Select Make, Count(VIN)
From EVD
Where County = 'King'  and city= 'Seattle'
Group by 1
Order by 2 desc;

-- Tesla Sells the most.

-- Xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

-- Incentive Utilization Analysis

-- Q1. How many types of CAFVS there?
Select distinct CAfv
from evd;

-- observation, 3

-- Q2. Count of CAFVS,

Select CAfv, Count(Cafv)
From Evd
group by Cafv;

-- Obesvation, a good number was elegible but a bigger no was unknown

-- Q3. Find the companies which maxium non eligible vehicles and then which have the maxium eligibility


DELIMITER $$

CREATE PROCEDURE CAFVStatus(IN No INT)
BEGIN
    -- Construct the dynamic query based on the input No
    SET @query = CONCAT(
        'SELECT * ',
        'FROM (',
        '    SELECT CAfv, ',
        '           Make, ',
        '           COUNT(CAFV) AS Count ',
        '    FROM evd ',
        '    WHERE CAFV = ',
        '        CASE ',
        '            WHEN ', No, ' = 1 THEN "Clean Alternative Fuel Vehicle Eligible" ',
        '            ELSE "Not eligible due to low battery range" ',
        '        END ',
        '    GROUP BY CAfv, ',
        '             Make ',
        ') E ',
        'ORDER BY Count DESC;'
    );

    -- Prepare and execute the dynamic query
    /*PREPARE stmt FROM @query;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;*/
END$$

DELIMITER ;

CALL CAFVStatus(1);


-- Q4. Find how the companies improved their Eligibility over years.
       
WITH Success AS (
    SELECT ModelYear, 
           COUNT(CAFV) AS EVs
    FROM Evd
    WHERE CAFV = "Clean Alternative Fuel Vehicle Eligible"
    GROUP BY ModelYear
)
SELECT *, 
       ROUND(((EVs - LAG(EVs) OVER (ORDER BY ModelYear)) / LAG(EVs) OVER (ORDER BY ModelYear)) * 100, 2) AS PercentageChange
FROM Success
ORDER BY ModelYear;
 -- Observation, Although the Overall elegibilty has increased over time in 2024 there was a decline which could be due to the less purchace of the vehicles.	   

 







